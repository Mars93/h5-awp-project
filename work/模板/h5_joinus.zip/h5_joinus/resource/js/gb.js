/**
 * Created by Administrator on 2015/11/4.
 */
var gb = {};
gb.IsGameReady = true;
gb.IsSeverReady = true;