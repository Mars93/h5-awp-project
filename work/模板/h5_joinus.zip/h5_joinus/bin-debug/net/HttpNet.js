/**
 * Created by milk on 16/3/8.
 */
var HttpNet;
(function (HttpNet) {
    HttpNet.GET = 0;
    HttpNet.POST = 1;
    function Initialize() {
        instance.Initialize();
    }
    HttpNet.Initialize = Initialize;
    function SendRequest(url, mode, data, comHandler, comTarget, errHandler, errTarget) {
        instance.SendRequest(url, mode, data, comHandler, comTarget, errHandler, errTarget);
    }
    HttpNet.SendRequest = SendRequest;
    var HttpSys = (function () {
        function HttpSys() {
            this.isInit = false;
        }
        var d = __define,c=HttpSys,p=c.prototype;
        p.Initialize = function () {
            if (this.isInit == false) {
                this.isInit = true;
            }
        };
        p.SendRequest = function (url, mode, data, completeHandler, comTarget, errHandler, errTarget) {
            var request = new egret.HttpRequest();
            request.responseType = egret.HttpResponseType.TEXT;
            var mSrc = "url";
            var value = "";
            if (data != void 0) {
                for (var i in data) {
                    if (value == "") {
                        value = value + i + "=" + data[i];
                    }
                    else {
                        value = value + "&" + i + "=" + data[i];
                    }
                }
            }
            if (mode == HttpNet.POST) {
                mSrc = egret.HttpMethod.POST;
                request.open(url, mSrc);
            }
            else {
                mSrc = egret.HttpMethod.GET;
                request.open(url + "?" + value, mSrc);
            }
            request.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            var respHandler = function (evt) {
                switch (evt.type) {
                    case egret.Event.COMPLETE:
                        typeof completeHandler == "function" && completeHandler.apply(comTarget, [1, request.response]);
                        break;
                    case egret.IOErrorEvent.IO_ERROR:
                        typeof errHandler == "function" && errHandler.apply(errTarget, [1, request.response]);
                        break;
                }
            };
            request.once(egret.Event.COMPLETE, respHandler, null);
            if (value != "" && mode == HttpNet.POST) {
                request.send(value);
            }
            else {
                request.send();
            }
        };
        return HttpSys;
    }());
    egret.registerClass(HttpSys,'HttpSys');
    var instance = new HttpSys();
})(HttpNet || (HttpNet = {}));
//# sourceMappingURL=HttpNet.js.map