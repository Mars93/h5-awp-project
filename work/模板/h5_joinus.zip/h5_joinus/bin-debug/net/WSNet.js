/**
 * Created by milk on 15/10/8.
 */
var WSNet;
(function (WSNet) {
    function Initialize() {
        instance.Initialize();
    }
    WSNet.Initialize = Initialize;
    function Connect(path, port) {
        instance.Connect(path, port);
    }
    WSNet.Connect = Connect;
    function Send(code, msg) {
        var info = {};
        info.code = code;
        if (msg == void 0) {
            info.msg = "";
        }
        else {
            info.msg = msg;
        }
        instance.Send(info);
    }
    WSNet.Send = Send;
    var WS = (function () {
        function WS() {
        }
        var d = __define,c=WS,p=c.prototype;
        p.Initialize = function () {
            this.socket = new egret.WebSocket();
            this.socket.type = egret.WebSocket.TYPE_STRING;
            this.socket.addEventListener(egret.ProgressEvent.SOCKET_DATA, this.onReceiveMessage, this);
            this.socket.addEventListener(egret.Event.CONNECT, this.onSocketOpen, this);
            this.socket.addEventListener(egret.Event.CLOSE, this.onSocketClose, this);
            this.socket.addEventListener(egret.IOErrorEvent.IO_ERROR, this.onSocketError, this);
        };
        p.Connect = function (path, port) {
            this.socket.connect(path, port);
        };
        p.Send = function (info) {
            var value = JSON.stringify(info);
            console.log("value:", value);
            this.socket.writeUTF(value);
            this.socket.flush();
        };
        p.onSocketError = function (e) {
            sr.Error();
        };
        p.onSocketOpen = function (e) {
            sr.Open();
        };
        p.onSocketClose = function (e) {
            sr.Close();
        };
        p.onReceiveMessage = function (e) {
            console.log(e);
        };
        return WS;
    }());
    egret.registerClass(WS,'WS');
    var instance = new WS();
})(WSNet || (WSNet = {}));
//# sourceMappingURL=WSNet.js.map