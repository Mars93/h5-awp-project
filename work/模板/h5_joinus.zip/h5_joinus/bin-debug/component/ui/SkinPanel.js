/**
 * Created by milk on 15/9/30.
 */
var SkinPanel = (function (_super) {
    __extends(SkinPanel, _super);
    function SkinPanel() {
        _super.call(this);
        this.listenerLst = [];
        if (typeof this["__class__"] == "string") {
            var path = "skins." + this["__class__"];
            this.skinName = path;
        }
        this.initialize();
        this.addEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStageHandler, this);
    }
    var d = __define,c=SkinPanel,p=c.prototype;
    p.registerListener = function (listenerTarget, eventType, func, target) {
        listenerTarget.addEventListener(eventType, func, target);
        var ld = {};
        ld.listenerTarget = listenerTarget;
        ld.eventType = eventType;
        ld.func = func;
        ld.target = target;
        this.listenerLst.push(ld);
    };
    p.clearListener = function (listenerTarget, eventType, func, target) {
        listenerTarget.removeEventListener(eventType, func, target);
        var ld = {};
        ld.listenerTarget = listenerTarget;
        ld.eventType = eventType;
        ld.func = func;
        ld.target = target;
        var index = this.listenerLst.indexOf(ld);
        if (index != -1) {
            this.listenerLst.splice(index, 1);
        }
    };
    p.onAddToStageHandler = function (e) {
        this.removeEventListener(egret.Event.ADDED_TO_STAGE, this.onAddToStageHandler, this);
        this.addEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStageHandler, this);
        this.registerListener(Core.Stage, egret.Event.RESIZE, this.onResizeHandler, this);
        this.onResizeHandler(null);
        this.onAdd();
    };
    p.onResizeHandler = function (e) {
        this.width = Core.Stage.stageWidth;
        this.height = Core.Stage.stageHeight;
    };
    p.onAdd = function () {
    };
    p.onRemove = function () {
    };
    p.onRemoveFromStageHandler = function (e) {
        var count = this.listenerLst.length;
        for (var i = 0; i < count; i++) {
            var ld = this.listenerLst[i];
            ld.listenerTarget.removeEventListener(ld.eventType, ld.func, ld.target);
        }
        this.removeEventListener(egret.Event.REMOVED_FROM_STAGE, this.onRemoveFromStageHandler, this);
        this.onRemove();
    };
    p.initialize = function () {
    };
    return SkinPanel;
}(eui.Panel));
egret.registerClass(SkinPanel,'SkinPanel');
//# sourceMappingURL=SkinPanel.js.map