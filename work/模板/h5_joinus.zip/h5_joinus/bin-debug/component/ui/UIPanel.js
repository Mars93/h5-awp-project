/**
 * Created by milk on 15/12/20.
 */
var UIPanel = (function (_super) {
    __extends(UIPanel, _super);
    function UIPanel() {
        _super.call(this);
    }
    var d = __define,c=UIPanel,p=c.prototype;
    p.partAdded = function (partName, instance) {
        if (this.uiLst == void 0) {
            this.uiLst = {};
        }
        if (this.cLst == void 0) {
            this.cLst = {};
        }
        var ta = instance;
        this.uiLst[partName] = ta;
    };
    p.initView = function () {
    };
    p.configHandler = function () {
    };
    p.initData = function () {
    };
    p.updateView = function () {
    };
    p.onAdd = function () {
        this.initData();
        this.initView();
        this.configHandler();
        this.updateView();
        this.addHandler();
    };
    p.addHandler = function () {
        for (var key in this.uiLst) {
            var handler = this.cLst[key];
            if (handler != void 0) {
                this.registerListener(this.uiLst[key], egret.TouchEvent.TOUCH_TAP, handler, this);
            }
        }
    };
    p.onCloseHandler = function (e) {
        Core.PopUpLayer.RemovePopUp(this);
    };
    p.getUI = function (key) {
        return this.uiLst[key];
    };
    return UIPanel;
}(SkinPanel));
egret.registerClass(UIPanel,'UIPanel');
//# sourceMappingURL=UIPanel.js.map