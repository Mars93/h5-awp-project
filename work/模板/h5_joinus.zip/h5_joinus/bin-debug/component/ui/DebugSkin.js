/**
 * Created by Administrator on 2016/6/6.
 */
var DebugSkin = (function (_super) {
    __extends(DebugSkin, _super);
    function DebugSkin() {
        _super.call(this);
    }
    var d = __define,c=DebugSkin,p=c.prototype;
    p.configHandler = function () {
        this.modeGroup = new eui.RadioButtonGroup();
        this.addRadioToGroup(["modeRadio0", "modeRadio1"], this.modeGroup);
        this.registerListener(this.modeGroup, eui.UIEvent.CHANGE, this.onModeChangeHandler, this);
        this.registerListener(this, egret.Event.ENTER_FRAME, this.nextFrameHandler, this);
    };
    p.nextFrameHandler = function (e) {
        this.clearListener(this, egret.Event.ENTER_FRAME, this.nextFrameHandler, this);
        var radio = this.getUI("modeRadio0");
        if (radio) {
            this.modeGroup.$setSelection(radio, true);
        }
    };
    //游戏模式选择
    p.onModeChangeHandler = function (e) {
        this.paramGroup.visible = e.target.selectedValue == "1" ? true : false;
        debug.IsDebug = this.paramGroup.visible;
    };
    p.addRadioToGroup = function (lst, group) {
        for (var i = 0; i < lst.length; i++) {
            var radio = this.getUI(lst[i]);
            if (radio) {
                radio.group = group;
            }
        }
    };
    return DebugSkin;
}(UIPanel));
egret.registerClass(DebugSkin,'DebugSkin');
//# sourceMappingURL=DebugSkin.js.map