/**
 * Created by milk on 15/10/7.
 */
var LaunchSkin = (function (_super) {
    __extends(LaunchSkin, _super);
    function LaunchSkin() {
        _super.call(this);
    }
    var d = __define,c=LaunchSkin,p=c.prototype;
    return LaunchSkin;
}(SkinPanel));
egret.registerClass(LaunchSkin,'LaunchSkin');
//# sourceMappingURL=LaunchSkin.js.map