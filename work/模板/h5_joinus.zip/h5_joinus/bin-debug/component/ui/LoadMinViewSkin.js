/**
 * Created by milk on 15/12/20.
 */
var LoadMinViewSkin = (function (_super) {
    __extends(LoadMinViewSkin, _super);
    function LoadMinViewSkin() {
        _super.call(this);
    }
    var d = __define,c=LoadMinViewSkin,p=c.prototype;
    p.onAdd = function () {
        this.registerListener(gr, GameEvent.LOAD_PROGRESS, this.onProgressHandler, this);
    };
    p.onProgressHandler = function (e) {
        var data = e.data;
        if (data) {
            var cur = data.cur;
            var total = data.total;
            var progress = Math.floor(cur / total * 100);
            this.setProgress(progress);
        }
    };
    p.setProgress = function (value) {
        if (value < 0) {
            value = 0;
        }
        else if (value > 100) {
            value = 100;
        }
        this.loadProgress.text = LoadMinViewSkin.BASE_TEXT + value.toString() + "%";
    };
    LoadMinViewSkin.BASE_TEXT = "a";
    return LoadMinViewSkin;
}(SkinPanel));
egret.registerClass(LoadMinViewSkin,'LoadMinViewSkin');
//# sourceMappingURL=LoadMinViewSkin.js.map