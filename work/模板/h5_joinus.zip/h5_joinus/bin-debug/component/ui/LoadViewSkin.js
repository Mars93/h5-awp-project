/**
 * Created by Administrator on 2015/9/28.
 */
var LoadViewSkin = (function (_super) {
    __extends(LoadViewSkin, _super);
    function LoadViewSkin() {
        _super.call(this);
    }
    var d = __define,c=LoadViewSkin,p=c.prototype;
    p.onAdd = function () {
        this.setProgress(0);
        this.registerListener(gr, GameEvent.LOAD_PROGRESS, this.onProgressHandler, this);
    };
    p.onProgressHandler = function (e) {
        var data = e.data;
        if (data) {
            var cur = data.cur;
            var total = data.total;
            var progress = Math.floor(cur / total * 100);
            this.setProgress(progress);
        }
    };
    p.setProgress = function (value) {
        if (value < 0) {
            value = 0;
        }
        else if (value > 100) {
            value = 100;
        }
        this.loadProgress.text = value.toString() + "%";
    };
    p.initialize = function () {
    };
    p.remove = function () {
    };
    return LoadViewSkin;
}(SkinPanel));
egret.registerClass(LoadViewSkin,'LoadViewSkin');
//# sourceMappingURL=LoadViewSkin.js.map