/**
 * Created by Milk on 2015/12/25.
 */
var sr;
(function (sr) {
    function addEventListener(type, listener, thisObject, useCapture, priority) {
        instance.addEventListener(type, listener, thisObject, useCapture, priority);
    }
    sr.addEventListener = addEventListener;
    function removeEventListener(type, listener, thisObject, useCapture) {
        instance.removeEventListener(type, listener, thisObject, useCapture);
    }
    sr.removeEventListener = removeEventListener;
    function Open() {
        instance.sendEvent(SocketEvent.OPEN);
    }
    sr.Open = Open;
    function Close() {
        instance.sendEvent(SocketEvent.CLOSE);
    }
    sr.Close = Close;
    function Error() {
        instance.sendEvent(SocketEvent.ERROR);
    }
    sr.Error = Error;
    var SocketResponse = (function (_super) {
        __extends(SocketResponse, _super);
        function SocketResponse() {
            _super.call(this);
        }
        var d = __define,c=SocketResponse,p=c.prototype;
        p.sendEvent = function (key, data) {
            var ge = new GameEvent(key, false, false, data);
            this.dispatchEvent(ge);
        };
        return SocketResponse;
    }(egret.EventDispatcher));
    egret.registerClass(SocketResponse,'SocketResponse');
    var instance = new SocketResponse();
})(sr || (sr = {}));
//# sourceMappingURL=SocketResponse.js.map