/**
 * Created by Administrator on 2015/9/28.
 */
var gr;
(function (gr) {
    function addEventListener(type, listener, thisObject, useCapture, priority) {
        instance.addEventListener(type, listener, thisObject, useCapture, priority);
    }
    gr.addEventListener = addEventListener;
    function removeEventListener(type, listener, thisObject, useCapture) {
        instance.removeEventListener(type, listener, thisObject, useCapture);
    }
    gr.removeEventListener = removeEventListener;
    function LoadProgress(cur, total, groupName) {
        var data = {};
        data.cur = cur;
        data.total = total;
        data.groupName = groupName;
        instance.sendEvent(GameEvent.LOAD_PROGRESS, data);
    }
    gr.LoadProgress = LoadProgress;
    function LoadGroupComplete(groupName) {
        instance.sendEvent(GameEvent.LOAD_GROUP_COMPLETE, groupName);
    }
    gr.LoadGroupComplete = LoadGroupComplete;
    function LoadComplete() {
        instance.sendEvent(GameEvent.LOAD_COMPETE);
    }
    gr.LoadComplete = LoadComplete;
    function Launch() {
        instance.sendEvent(GameEvent.LAUNCH);
    }
    gr.Launch = Launch;
    function EffectEnd() {
        instance.sendEvent(GameEvent.EFFECT_END);
    }
    gr.EffectEnd = EffectEnd;
    function WxReady() {
        instance.sendEvent(GameEvent.WX_READY);
    }
    gr.WxReady = WxReady;
    function Debug() {
        instance.sendEvent(GameEvent.DEBUG);
    }
    gr.Debug = Debug;
    function Start() {
        instance.sendEvent(GameEvent.START);
    }
    gr.Start = Start;
    //-------这里自动添加代码分割线-------
    var GameResponse = (function (_super) {
        __extends(GameResponse, _super);
        function GameResponse() {
            _super.call(this);
        }
        var d = __define,c=GameResponse,p=c.prototype;
        p.sendEvent = function (key, data) {
            var ge = new GameEvent(key, false, false, data);
            this.dispatchEvent(ge);
        };
        return GameResponse;
    }(egret.EventDispatcher));
    egret.registerClass(GameResponse,'GameResponse');
    var instance = new GameResponse();
})(gr || (gr = {}));
//# sourceMappingURL=GameResponse.js.map