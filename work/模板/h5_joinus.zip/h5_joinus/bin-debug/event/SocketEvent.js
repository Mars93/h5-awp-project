/**
 * Created by milk on 15/12/26.
 */
var SocketEvent = (function (_super) {
    __extends(SocketEvent, _super);
    function SocketEvent(type, bubbles, cancelable, data) {
        if (bubbles === void 0) { bubbles = false; }
        if (cancelable === void 0) { cancelable = false; }
        _super.call(this, type, bubbles, cancelable, data);
    }
    var d = __define,c=SocketEvent,p=c.prototype;
    SocketEvent.OPEN = "open";
    SocketEvent.CLOSE = "close";
    SocketEvent.ERROR = "error";
    return SocketEvent;
}(egret.Event));
egret.registerClass(SocketEvent,'SocketEvent');
//# sourceMappingURL=SocketEvent.js.map