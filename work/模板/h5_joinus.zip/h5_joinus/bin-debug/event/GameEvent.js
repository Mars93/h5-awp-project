/**
 * Created by Administrator on 2015/9/28.
 */
var GameEvent = (function (_super) {
    __extends(GameEvent, _super);
    function GameEvent(type, bubbles, cancelable, data) {
        if (bubbles === void 0) { bubbles = false; }
        if (cancelable === void 0) { cancelable = false; }
        _super.call(this, type, bubbles, cancelable, data);
    }
    var d = __define,c=GameEvent,p=c.prototype;
    GameEvent.LAUNCH = "launch";
    GameEvent.DEBUG = "debug";
    //-------这里自动添加代码分割线-------
    GameEvent.START = "start";
    GameEvent.LOAD_PROGRESS = "load_progress";
    GameEvent.LOAD_COMPETE = "load_complete";
    GameEvent.LOAD_GROUP_COMPLETE = "load_group_complete";
    GameEvent.EFFECT_END = "effect_end";
    GameEvent.WX_READY = "wx_ready";
    return GameEvent;
}(egret.Event));
egret.registerClass(GameEvent,'GameEvent');
//# sourceMappingURL=GameEvent.js.map