/**
 * Created by Administrator on 2015/1/28.
 */
var Func;
(function (Func) {
    function BtnClickEffect(target) {
        if (target.scaleX != 1) {
            return;
        }
        var pp = 0.8; //系数
        var x = target.x;
        var y = target.y;
        var nx = target.x + target.width * 0.5 - target.width * pp * 0.5;
        var ny = target.y + target.height * 0.5 - target.height * pp * 0.5;
        target.scaleY = pp;
        target.scaleX = pp;
        target.x = nx;
        target.y = ny;
        setTimeout(Func.clickReset, 100, target, x, y);
    }
    Func.BtnClickEffect = BtnClickEffect;
    // 0至value随机一个数
    function Random(value) {
        var result = 0;
        if (value > 0) {
            result = Math.floor(Math.random() * 10000) % value;
        }
        return result;
    }
    Func.Random = Random;
    //恢复原貌
    function clickReset(target, x, y) {
        target.scaleX = 1;
        target.scaleY = 1;
        target.x = x;
        target.y = y;
    }
    Func.clickReset = clickReset;
    function AddChild(parent, target, scale, x, y) {
        if (scale == void 0) {
            scale = 1;
        }
        if (x == void 0) {
            x = Core.Stage.stageWidth * 0.5;
        }
        if (y == void 0) {
            y = Core.Stage.stageHeight * 0.5;
        }
        parent.addChild(target);
        target.scaleX = scale;
        target.scaleY = scale;
        target.x = x;
        target.y = y;
    }
    Func.AddChild = AddChild;
})(Func || (Func = {}));
//# sourceMappingURL=func.js.map