var GameManage;
(function (GameManage) {
    function Initialize() {
        instance.Initialize();
    }
    GameManage.Initialize = Initialize;
    var GameSys = (function () {
        function GameSys() {
        }
        var d = __define,c=GameSys,p=c.prototype;
        p.Initialize = function () {
            //[事件，打开界面前的触发函数，打开界面方式(0 UI显示 1 弹窗),要被打开的界面类,打开模式mode,打开界面后的触发函数]
            this.lst = [
                [GameEvent.LAUNCH, null, GameSys.UI_NORMAL, LaunchSkin, 1, null],
                [GameEvent.DEBUG, null, GameSys.UI_NORMAL, DebugSkin, 1, null],
            ];
            var count = this.lst.length;
            for (var i = 0; i < count; i++) {
                var arr = this.lst[i];
                this.register(arr[0], this.handler, this);
            }
        };
        p.register = function (type, callback, target) {
            gr.addEventListener(type, callback, target);
        };
        p.handler = function (e) {
            var count = this.lst.length;
            for (var i = 0; i < count; i++) {
                var arr = this.lst[i];
                if (arr[0] == e.type) {
                    if (arr[1] != null && typeof arr[1] == "function") {
                        arr[1].apply(this);
                    }
                    //显示界面
                    if (arr[2] == 0 && arr[3] != null) {
                        Core.UILayer.Show(arr[3], arr[4]);
                    }
                    else if (arr[2] == 1 && arr[3] != null) {
                        Core.PopUpLayer.AddPopUp(arr[3], arr[4]);
                    }
                    if (arr[5] != null && typeof arr[5] == "function") {
                        arr[5].apply(this);
                    }
                    break;
                }
            }
        };
        GameSys.UI_NORMAL = 0; //正常现实
        GameSys.UI_POP_UP = 1; //弹窗
        return GameSys;
    }());
    egret.registerClass(GameSys,'GameSys');
    var instance = new GameSys();
})(GameManage || (GameManage = {}));
//# sourceMappingURL=GameManage.js.map