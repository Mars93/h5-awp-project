/**
 * Created by Administrator on 2015/5/25.
 */
var LoadManage;
(function (LoadManage) {
    function Initialize() {
        instance.Initialize();
    }
    LoadManage.Initialize = Initialize;
    function StartLoad(arr, classView) {
        instance.StartLoad(arr, classView);
    }
    LoadManage.StartLoad = StartLoad;
    function GetView() {
        return instance.GetView();
    }
    LoadManage.GetView = GetView;
    function getCurLoad() {
        return instance._curLoad;
    }
    LoadManage.getCurLoad = getCurLoad;
    function getTotalLoad() {
        return instance._totalLoad;
    }
    LoadManage.getTotalLoad = getTotalLoad;
    var LoadSys = (function () {
        function LoadSys() {
            this._totalLoad = 0;
            this._curLoad = 0;
        }
        var d = __define,c=LoadSys,p=c.prototype;
        p.Initialize = function () {
            RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this);
            RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress, this);
        };
        p.StartLoad = function (arr, classView) {
            if (classView) {
                this._view = Core.LoadLayer.ShowLoadView(classView);
            }
            if (arr != void 0 && arr.length > 0) {
                this._loadArr = arr;
                this._totalLoad = this.getTotalNeedLoad(this._loadArr);
                this._curLoad = 0;
                var count = this._loadArr.length;
                for (var i = 0; i < count; i++) {
                    RES.loadGroup(this._loadArr[i], count - i);
                }
            }
            else {
                this.endLoad();
            }
        };
        p.onResourceLoadComplete = function (e) {
            gr.LoadGroupComplete(e.groupName);
            if (this._curLoad >= this._totalLoad) {
                this.endLoad();
            }
        };
        p.endLoad = function () {
            if (this._view) {
                Core.LoadLayer.RemoveLoadView();
                this._view = null;
            }
            gr.LoadComplete();
            this._loadArr = null;
        };
        p.onResourceProgress = function (e) {
            if (this._loadArr.indexOf(e.groupName) != -1) {
                this._curLoad = this._curLoad + 1;
                gr.LoadProgress(this._curLoad, this._totalLoad, e.groupName);
            }
        };
        p.GetView = function () {
            return this._view;
        };
        p.getTotalNeedLoad = function (arr) {
            var num = 0;
            var count = arr.length;
            for (var i = 0; i < count; i++) {
                var rArr = RES.getGroupByName(arr[i]);
                num = num + rArr.length;
            }
            return num;
        };
        return LoadSys;
    }());
    egret.registerClass(LoadSys,'LoadSys');
    var instance = new LoadSys();
})(LoadManage || (LoadManage = {}));
//# sourceMappingURL=LoadManage.js.map