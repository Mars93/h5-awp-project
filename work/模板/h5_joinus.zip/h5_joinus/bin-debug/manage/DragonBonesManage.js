/**
 * Created by Administrator on 2015/9/18.
 */
var DragonBonesManage;
(function (DragonBonesManage) {
    function Initialize() {
        instance.Initialize();
    }
    DragonBonesManage.Initialize = Initialize;
    function AddDragonBones(key) {
        instance.AddDragonBones(key);
    }
    DragonBonesManage.AddDragonBones = AddDragonBones;
    function GetArmature(key) {
        return instance.GetArmature(key);
    }
    DragonBonesManage.GetArmature = GetArmature;
    function RemoveArmature(armature) {
        return instance.RemoveArmature(armature);
    }
    DragonBonesManage.RemoveArmature = RemoveArmature;
    var DragonBonesSys = (function () {
        function DragonBonesSys() {
        }
        var d = __define,c=DragonBonesSys,p=c.prototype;
        p.Initialize = function () {
            this.dragonBonesFactory = new dragonBones.EgretFactory();
            var lastTime = 0;
            egret.startTick(function (frameTime) {
                if (lastTime == 0) {
                    lastTime = frameTime;
                }
                else {
                    var nt = (frameTime - lastTime) / 1000;
                    dragonBones.WorldClock.clock.advanceTime(nt);
                    lastTime = frameTime;
                }
                return true;
            }, this);
        };
        p.AddDragonBones = function (key) {
            var dragonBonesData = RES.getRes(key + "_json");
            var textureData = RES.getRes(key + "_texture_json");
            var texture = RES.getRes(key + "_texture_png");
            this.dragonBonesFactory.addDragonBonesData(dragonBones.DataParser.parseDragonBonesData(dragonBonesData));
            this.dragonBonesFactory.addTextureAtlas(new dragonBones.EgretTextureAtlas(texture, textureData));
        };
        p.GetArmature = function (key) {
            var armature = this.dragonBonesFactory.buildArmature(key);
            dragonBones.WorldClock.clock.add(armature);
            return armature;
        };
        p.RemoveArmature = function (armature) {
            if (armature) {
                if (armature.display.parent != null) {
                    armature.display.parent.removeChild(armature.display);
                }
                dragonBones.WorldClock.clock.remove(armature);
            }
        };
        return DragonBonesSys;
    }());
    egret.registerClass(DragonBonesSys,'DragonBonesSys');
    var instance = new DragonBonesSys();
})(DragonBonesManage || (DragonBonesManage = {}));
//# sourceMappingURL=DragonBonesManage.js.map