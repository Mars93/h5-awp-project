/**
 * Created by Administrator on 2015/12/4.
 */
var MusicManage;
(function (MusicManage) {
    function Initialize() {
        instance.Initialize();
    }
    MusicManage.Initialize = Initialize;
    function PlayMusic(name, type) {
        instance.PlayMusic(name, type);
    }
    MusicManage.PlayMusic = PlayMusic;
    function StopMusic(name) {
        instance.StopMusic(name);
    }
    MusicManage.StopMusic = StopMusic;
    var MusicSys = (function () {
        function MusicSys() {
            this.soundLst = {};
        }
        var d = __define,c=MusicSys,p=c.prototype;
        p.Initialize = function () {
            var lst = RES.getGroupByName(MusicSys.MUSIC_GROUP);
            var count = lst.length;
            for (var i = 0; i < count; i++) {
                var item = lst[i];
                var soundNick = item.name;
                var soundSrc = item.url;
                this.addMusic(soundNick, soundSrc);
            }
        };
        p.addMusic = function (name, src) {
            var sound = this.soundLst[name];
            if (sound == void 0) {
                var dom = document.getElementsByTagName("body")[0];
                var nDiv = document.createElement("div");
                nDiv.style.width = "0px";
                nDiv.style.height = "0px";
                nDiv.style.position = "absolute";
                sound = document.createElement("audio");
                sound.id = name;
                //sound.preload= "auto";
                sound.src = src;
                sound.load(); //先缓存起来
                nDiv.appendChild(sound);
                dom.appendChild(nDiv);
                this.soundLst[name] = sound;
            }
            return sound;
        };
        p.PlayMusic = function (name, type) {
            if (type == void 0) {
                type = MusicSys.EFFECT;
            }
            var sound = this.soundLst[name];
            if (sound != void 0) {
                if (type == MusicSys.EFFECT) {
                    delete sound["autoplay"];
                    delete sound["loop"];
                    sound.removeEventListener("ended", this.playFunc, false);
                    var tag = 0;
                    while (sound.paused == false) {
                        tag++;
                        sound = this.addMusic(name + tag.toString(), sound.src);
                    }
                    sound.play();
                }
                else if (type == MusicSys.BACKGROUND) {
                    sound["autoplay"] = "autoplay";
                    sound.play();
                    sound.addEventListener("ended", this.playFunc, false);
                }
            }
        };
        p.playFunc = function (e) {
            var sound = e.target;
            setTimeout(function () { sound.play(); }, 100);
        };
        p.StopMusic = function (name) {
            var sound = this.soundLst[name];
            if (sound != void 0) {
                if (sound.hasOwnProperty("autoplay")) {
                    delete sound["autoplay"];
                    sound.removeEventListener("ended", this.playFunc, false);
                }
                sound.pause();
            }
        };
        MusicSys.EFFECT = 0;
        MusicSys.BACKGROUND = 1;
        MusicSys.MUSIC_GROUP = "music";
        return MusicSys;
    }());
    egret.registerClass(MusicSys,'MusicSys');
    var instance = new MusicSys();
})(MusicManage || (MusicManage = {}));
//# sourceMappingURL=MusicManager.js.map