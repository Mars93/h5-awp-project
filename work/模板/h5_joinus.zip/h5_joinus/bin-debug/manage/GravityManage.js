/**
 * Created by Administrator on 2015/12/7.
 */
var GravityManage;
(function (GravityManage) {
    function addEventListener(type, listener, thisObject, useCapture, priority) {
        if (useCapture === void 0) { useCapture = false; }
        if (priority === void 0) { priority = 0; }
        instance.addEventListener(type, listener, thisObject, useCapture, priority);
    }
    GravityManage.addEventListener = addEventListener;
    function removeEventListener(type, listener, thisObject, useCapture) {
        if (useCapture === void 0) { useCapture = false; }
        instance.removeEventListener(type, listener, thisObject, useCapture);
    }
    GravityManage.removeEventListener = removeEventListener;
    function Start() {
        instance.Start();
    }
    GravityManage.Start = Start;
    function Stop() {
        instance.Stop();
    }
    GravityManage.Stop = Stop;
    var GravityEvent = (function (_super) {
        __extends(GravityEvent, _super);
        function GravityEvent(type, bubbles, cancelable, data) {
            if (bubbles === void 0) { bubbles = false; }
            if (cancelable === void 0) { cancelable = false; }
            _super.call(this, type, bubbles, cancelable, data);
            this.angleX = 0;
            this.angleY = 0;
            this.angleZ = 0;
        }
        var d = __define,c=GravityEvent,p=c.prototype;
        GravityEvent.CHANGE = "change";
        return GravityEvent;
    }(egret.Event));
    GravityManage.GravityEvent = GravityEvent;
    egret.registerClass(GravityEvent,'GravityManage.GravityEvent');
    var GravitySys = (function (_super) {
        __extends(GravitySys, _super);
        function GravitySys() {
            _super.call(this);
            this.initialize();
        }
        var d = __define,c=GravitySys,p=c.prototype;
        p.initialize = function () {
        };
        p.Start = function () {
            window.ondevicemotion = function (e) {
                var ge = new GravityEvent(GravityEvent.CHANGE);
                // ge.angleX = e.rotationRate.beta;
                // ge.angleY = e.rotationRate.gamma;
                // ge.angleZ = e.rotationRate.alpha;
                ge.angleX = e.accelerationIncludingGravity.x;
                ge.angleY = e.accelerationIncludingGravity.y;
                ge.angleZ = e.accelerationIncludingGravity.z;
                instance.dispatchEvent(ge);
            };
        };
        p.Stop = function () {
            window.ondevicemotion = function (e) {
            };
        };
        return GravitySys;
    }(egret.EventDispatcher));
    egret.registerClass(GravitySys,'GravitySys');
    var instance = new GravitySys();
})(GravityManage || (GravityManage = {}));
//# sourceMappingURL=GravityManage.js.map