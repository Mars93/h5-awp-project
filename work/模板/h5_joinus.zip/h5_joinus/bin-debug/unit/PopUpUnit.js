/**
 * Created by Administrator on 2015/10/28.
 */
var PopUpUnit = (function (_super) {
    __extends(PopUpUnit, _super);
    function PopUpUnit(alpha) {
        _super.call(this);
        this.modalAlpha = alpha;
        this.initialize();
    }
    var d = __define,c=PopUpUnit,p=c.prototype;
    p.initialize = function () {
        this.bg = new egret.Bitmap();
        this.bg.alpha = this.modalAlpha;
        this.bg.texture = RES.getRes("black_jpg");
        this.bg.scale9Grid = new egret.Rectangle(1, 1, 1, 1);
        this.bg.width = Core.Stage.stageWidth;
        this.bg.height = Core.Stage.stageHeight;
        this.addChild(this.bg);
    };
    p.SetChild = function (value) {
        if (this._child && this._child.parent) {
            this._child.parent.removeChild(this._child);
        }
        this._child = value;
        this.addChild(value);
    };
    p.GetChild = function () {
        return this._child;
    };
    return PopUpUnit;
}(egret.Sprite));
egret.registerClass(PopUpUnit,'PopUpUnit');
//# sourceMappingURL=PopUpUnit.js.map