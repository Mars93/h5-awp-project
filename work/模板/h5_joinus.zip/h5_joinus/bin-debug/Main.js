var Main = (function (_super) {
    __extends(Main, _super);
    function Main() {
        _super.apply(this, arguments);
        this.loadArr = [];
    }
    var d = __define,c=Main,p=c.prototype;
    p.createChildren = function () {
        //注入自定义的素材解释器
        this.stage.registerImplementation("eui.IAssetAdapter", new AssetAdapter());
        HttpNet.Initialize();
        _super.prototype.createChildren.call(this);
        //var theme = new eui.Theme("resource/default.thm.json", this.stage);
        RES.registerAnalyzer("exml", EXMLAnalyzer);
        //RES.registerAnalyzer("xml",RES.XMLAnalyzer);
        RES.addEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
        RES.loadConfig("resource/default.res.json", "resource/");
    };
    p.onConfigComplete = function (e) {
        RES.removeEventListener(RES.ResourceEvent.CONFIG_COMPLETE, this.onConfigComplete, this);
        RES.addEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this);
        RES.addEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress, this);
        RES.loadGroup("LoadViewSkin");
        if (typeof RES["configInstance"]["groupDic"] != "undefined") {
            this.loadArr = [];
            for (var key in RES["configInstance"]["groupDic"]) {
                if (key != "LoadViewSkin" && key != "music") {
                    this.loadArr.unshift(key);
                }
            }
        }
    };
    p.onResourceProgress = function (e) {
    };
    p.onResourceLoadComplete = function (e) {
        if (e.groupName == "LoadViewSkin") {
            RES.removeEventListener(RES.ResourceEvent.GROUP_COMPLETE, this.onResourceLoadComplete, this);
            RES.removeEventListener(RES.ResourceEvent.GROUP_PROGRESS, this.onResourceProgress, this);
            this.createScene();
            gr.addEventListener(GameEvent.LOAD_GROUP_COMPLETE, this.onLoadGroupCompleteHandler, this);
            gr.addEventListener(GameEvent.LOAD_COMPETE, this.onLoadCompleteHandler, this);
            LoadManage.Initialize();
            LoadManage.StartLoad(this.loadArr, LoadViewSkin);
        }
    };
    p.onLoadGroupCompleteHandler = function (e) {
        // var groupName:string = <string>e.data;
        // if( groupName == "LaunchSkin" ){
        //     this.startShow();
        // }
    };
    p.onLoadCompleteHandler = function (e) {
        this.startShow();
    };
    p.startShow = function () {
        gr.removeEventListener(GameEvent.LOAD_PROGRESS, this.onLoadGroupCompleteHandler, this);
        gr.removeEventListener(GameEvent.LOAD_COMPETE, this.onLoadCompleteHandler, this);
        //DragonBonesManage.Initialize();
        gr.addEventListener(GameEvent.START, this.onStartHandler, this);
        gb.IsGameReady = true;
        if (debug.IsDebug || gb.IsServerReady) {
            gr.Start();
        }
    };
    p.onStartHandler = function (e) {
        gr.removeEventListener(GameEvent.START, this.onStartHandler, this);
        gr.Launch();
    };
    p.createScene = function () {
        //初始化层
        Core.Stage = this.stage;
        Core.GameLayer = new GameLayer();
        this.addChild(Core.GameLayer);
        Core.UILayer = new UILayer();
        this.addChild(Core.UILayer);
        Core.MusicLayer = new MusicLayer();
        this.addChild(Core.MusicLayer);
        Core.PopUpLayer = new PopUpLayer();
        this.addChild(Core.PopUpLayer);
        Core.LoadLayer = new LoadLayer();
        this.addChild(Core.LoadLayer);
        Core.UILayer.SetLoadView(LoadViewSkin);
        GameManage.Initialize();
    };
    return Main;
}(eui.UILayer));
egret.registerClass(Main,'Main');
//# sourceMappingURL=Main.js.map