/**
 * Created by milk on 15/10/8.
 */
var EXMLAnalyzer = (function (_super) {
    __extends(EXMLAnalyzer, _super);
    function EXMLAnalyzer() {
        _super.call(this);
    }
    var d = __define,c=EXMLAnalyzer,p=c.prototype;
    p.analyzeData = function (resItem, data) {
        var name = resItem["name"];
        if (this.fileDic[name] || !data) {
            return;
        }
        var clzz = EXML.parse(data);
        this.fileDic[name] = clzz;
    };
    return EXMLAnalyzer;
}(RES.TextAnalyzer));
egret.registerClass(EXMLAnalyzer,'EXMLAnalyzer');
//# sourceMappingURL=EXMLAnalyzer.js.map