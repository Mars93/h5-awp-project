/**
 * Created by Administrator on 2015/9/28.
 */
var Core = (function () {
    function Core() {
    }
    var d = __define,c=Core,p=c.prototype;
    return Core;
}());
egret.registerClass(Core,'Core');
//# sourceMappingURL=Core.js.map