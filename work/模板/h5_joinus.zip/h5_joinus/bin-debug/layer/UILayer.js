/**
 * Created by Administrator on 2015/9/28.
 */
var UILayer = (function (_super) {
    __extends(UILayer, _super);
    function UILayer() {
        _super.call(this);
        this.initialize();
    }
    var d = __define,c=UILayer,p=c.prototype;
    p.initialize = function () {
    };
    p.SetLoadView = function (value) {
        this.loadView = value;
    };
    p.Show = function (classFactory, mode) {
        if (mode === void 0) {
            mode = 1;
        }
        if (this.curClass == classFactory) {
            return;
        }
        //检查资源是否加载了
        var className = egret.getQualifiedClassName(classFactory);
        if (typeof className != "string") {
            return;
        }
        if (RES.isGroupLoaded(className) == false) {
            gr.addEventListener(GameEvent.LOAD_COMPETE, this.onUILoadCompleteHandler, this);
            gr.addEventListener(GameEvent.LOAD_GROUP_COMPLETE, this.onUILoadGroupCompleteHandler, this);
            UILayer.ReadyClassFactory = classFactory;
            UILayer.ReadyMode = mode;
            UILayer.ReadyClassName = className;
            LoadManage.StartLoad([className], null);
            Core.LoadLayer.ShowMinLoading();
        }
        else {
            this.startClear();
            this.startShow(classFactory, mode);
        }
    };
    p.onUILoadGroupCompleteHandler = function (e) {
        var groupName = e.data;
        if (groupName != void 0 && groupName == UILayer.ReadyClassName) {
            this.startClear();
        }
    };
    p.onUILoadCompleteHandler = function (e) {
        this.startClear();
    };
    p.startClear = function () {
        if (UILayer.ReadyClassFactory) {
            this.startShow(UILayer.ReadyClassFactory, UILayer.ReadyMode);
        }
        Core.LoadLayer.CloseMinLoading();
        gr.removeEventListener(GameEvent.LOAD_GROUP_COMPLETE, this.onUILoadGroupCompleteHandler, this);
        gr.removeEventListener(GameEvent.LOAD_COMPETE, this.onUILoadCompleteHandler, this);
        UILayer.ReadyClassFactory = null;
        UILayer.ReadyMode = null;
        UILayer.ReadyClassName = null;
    };
    p.startShow = function (classFactory, mode) {
        if (this.curShow) {
            this.lastShow = this.curShow;
        }
        this.curClass = classFactory;
        if (classFactory != null) {
            this.curShow = new classFactory();
        }
        if (this.curShow) {
            switch (mode) {
                case 0:
                case 1:
                case 2:
                    this.addChild(this.curShow);
                    break;
                case 3:
                    this.addChildAt(this.curShow, this.numChildren - 1);
                    break;
            }
        }
        if (this.lastShow) {
            switch (mode) {
                case 1:
                    this.curShow.alpha = 0;
                    egret.Tween.get(this.curShow).to({ alpha: 1 }, UILayer.CHANGE_TIME).call(this.Close, this).call(gr.EffectEnd, gr);
                    egret.Tween.get(this.lastShow).to({ alpha: 0 }, UILayer.CHANGE_TIME);
                    break;
                case 2:
                    this.curShow.y = Core.Stage.height;
                    egret.Tween.get(this.curShow).to({ y: 0 }, UILayer.CHANGE_TIME).call(this.Close, this).call(gr.EffectEnd, gr);
                    break;
                case 3:
                    egret.Tween.get(this.lastShow).to({ y: Core.Stage.height }, UILayer.CHANGE_TIME).call(this.Close, this).call(gr.EffectEnd, gr);
                    break;
                default:
                    this.Close();
                    gr.EffectEnd();
                    break;
            }
        }
        else {
            this.Close();
            gr.EffectEnd();
        }
    };
    p.Close = function () {
        if (this.lastShow && this.lastShow.parent) {
            this.lastShow.parent.removeChild(this.lastShow);
            this.lastShow = null;
        }
    };
    UILayer.CHANGE_TIME = 500; //单位:毫秒
    return UILayer;
}(eui.Group));
egret.registerClass(UILayer,'UILayer');
//# sourceMappingURL=UILayer.js.map