/**
 * Created by milk on 15/12/20.
 */
var LoadLayer = (function (_super) {
    __extends(LoadLayer, _super);
    function LoadLayer() {
        _super.call(this);
        this.initialize();
    }
    var d = __define,c=LoadLayer,p=c.prototype;
    p.initialize = function () {
    };
    p.ShowLoadView = function (classFactory, alpha) {
        var target;
        if (alpha == void 0) {
            alpha = PopUpLayer.ModalAlpha;
        }
        if (this.curClass != classFactory) {
            var pu = new PopUpUnit();
            target = new classFactory();
            target["anchorOffsetX"] = Core.Stage.stageWidth * 0.5;
            target["anchorOffsetY"] = Core.Stage.stageHeight * 0.5;
            target["x"] = Core.Stage.stageWidth * 0.5;
            target["y"] = Core.Stage.stageHeight * 0.5;
            pu.SetChild(target);
            this.addChild(pu);
            this.popUpUnit = pu;
        }
        return target;
    };
    p.RemoveLoadView = function () {
        if (this.popUpUnit) {
            if (this.popUpUnit.parent != null) {
                this.popUpUnit.parent.removeChild(this.popUpUnit);
            }
            this.popUpUnit = null;
        }
    };
    p.ShowMinLoading = function () {
        if (this.minView == null) {
            this.minView = new LoadMinViewSkin();
            this.addChild(this.minView);
            this.minView.touchChildren = false;
            this.minView.touchEnabled = false;
            this.minView.alpha = 0;
            egret.Tween.get(this.minView).to({ alpha: 1 }, 500);
        }
    };
    p.CloseMinLoading = function () {
        if (this.minView) {
            egret.Tween.removeTweens(this.minView);
            if (this.minView.parent != null) {
                this.minView.parent.removeChild(this.minView);
            }
            this.minView = null;
        }
    };
    LoadLayer.ModalAlpha = 0.8;
    return LoadLayer;
}(eui.Group));
egret.registerClass(LoadLayer,'LoadLayer');
//# sourceMappingURL=LoadLayer.js.map