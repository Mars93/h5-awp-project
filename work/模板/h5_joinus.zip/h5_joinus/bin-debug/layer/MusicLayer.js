/**
 * Created by Administrator on 2015/11/2.
 */
var MusicLayer = (function (_super) {
    __extends(MusicLayer, _super);
    function MusicLayer() {
        _super.call(this);
        this.initialize();
    }
    var d = __define,c=MusicLayer,p=c.prototype;
    p.initialize = function () {
        this.btn = new egret.Bitmap();
        this.btn.anchorOffsetX = MusicLayer.BG_WIDTH * 0.5;
        this.btn.anchorOffsetY = MusicLayer.BG_HEIGHT * 0.5;
        this.btn.touchEnabled = true;
        this.addChild(this.btn);
        this.btn.x = 700;
        this.btn.y = 50;
        this.btn.addEventListener(egret.TouchEvent.TOUCH_TAP, this.onTouchHandler, this);
        this._sound = RES.getRes("bg_mp3");
    };
    p.onTouchHandler = function (e) {
        this.IsPlay = !this.IsPlay;
    };
    d(p, "IsPlay"
        ,function () {
            return this._isPlay;
        }
        ,function (value) {
            if (this._isPlay != value) {
                this._isPlay = value;
                if (this._isPlay) {
                    this._chanel = this._sound.play();
                    this.btn.texture = RES.getRes("play_png");
                    egret.Tween.get(this.btn, { loop: true }).to({ rotation: 359 }, 1000);
                }
                else {
                    egret.Tween.removeTweens(this.btn);
                    this.btn.rotation = 0;
                    this.btn.texture = RES.getRes("stop_png");
                    if (this._chanel) {
                        this._chanel.stop();
                    }
                }
            }
        }
    );
    MusicLayer.BG_WIDTH = 48;
    MusicLayer.BG_HEIGHT = 48;
    return MusicLayer;
}(eui.Group));
egret.registerClass(MusicLayer,'MusicLayer');
//# sourceMappingURL=MusicLayer.js.map