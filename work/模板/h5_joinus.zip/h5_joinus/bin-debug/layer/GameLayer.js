/**
 * Created by Administrator on 2015/9/28.
 */
var GameLayer = (function (_super) {
    __extends(GameLayer, _super);
    function GameLayer() {
        _super.call(this);
        this.initialize();
    }
    var d = __define,c=GameLayer,p=c.prototype;
    p.initialize = function () {
    };
    return GameLayer;
}(eui.Group));
egret.registerClass(GameLayer,'GameLayer');
//# sourceMappingURL=GameLayer.js.map