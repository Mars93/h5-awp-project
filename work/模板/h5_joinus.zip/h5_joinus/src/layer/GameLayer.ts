/**
 * Created by Administrator on 2015/9/28.
 */
class GameLayer extends eui.Group{
    constructor(){
        super();
        this.initialize();
    }

    private initialize():void{

    }
}