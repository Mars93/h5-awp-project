/**
 * Created by milk on 15/10/7.
 */
class LaunchSkin extends SkinPanel{
    constructor(){
        super();
    }
}