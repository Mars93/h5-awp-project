/**
 * Created by milk on 15/12/28.
 */
module SocketPort {
    export interface Info{
        code:string;
        msg:any;
    }
}