/**
 * Created by milk on 15/9/30.
 */
interface ListenerData{
    listenerTarget:egret.EventDispatcher;
    eventType:string;
    func:Function;
    target:any;
}