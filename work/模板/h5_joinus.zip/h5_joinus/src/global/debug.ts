/**
 * Created by Administrator on 2016/6/6.
 */
declare class debug{
    static IsDebug:boolean;
}