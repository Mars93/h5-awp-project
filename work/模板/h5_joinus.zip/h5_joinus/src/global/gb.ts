/**
 * Created by Administrator on 2016/6/6.
 */
declare class  gb{
    static IsGameReady:boolean;
    static IsServerReady:boolean;
}