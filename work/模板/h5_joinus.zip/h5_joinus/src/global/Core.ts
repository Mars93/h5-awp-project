/**
 * Created by Administrator on 2015/9/28.
 */
class Core {
    //场景
    static Stage:egret.Stage;

    //游戏层
    static GameLayer:GameLayer;

    //ui层
    static UILayer:UILayer;

    //音乐层
    static MusicLayer:MusicLayer;

    //弹窗层
    static PopUpLayer:PopUpLayer;

    static LoadLayer:LoadLayer;
}