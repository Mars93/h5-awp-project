declare class GameData{

}