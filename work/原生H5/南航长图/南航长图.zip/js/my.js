// JavaScript Document
$(document).ready(function(){
    $(".tipsBtn4").click(function(){
		$("#tipsPage4").show();
	});
	$(".tipsBtn5").click(function(){
		$("#tipsPage5").show();
	});
	$(".tipsBtn6").click(function(){
		$("#tipsPage6").show();
	});

	$(".closeTips4").click(function(){
		$("#tipsPage4").hide();
	});
	$(".closeTips5").click(function(){
		$("#tipsPage5").hide();
	});
	$(".closeTips6").click(function(){
		$("#tipsPage6").hide();
	});

});
